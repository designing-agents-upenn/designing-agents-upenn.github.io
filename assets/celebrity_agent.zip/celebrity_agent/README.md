# HW3 Agent Skeleton

Minimal starter scaffold for a celebrity-style conversational agent with:

- a memory store (ingest, index, retrieve)
- a content module (grounded content planning)
- a style module (voice transformation)
- a chat runner that wires everything together

## Project layout

```text
celebrity_agent/
  README.md
  requirements.txt
  data/
    sources.jsonl
    index.json
  src/
    memory_store.py
    content_module.py
    style_module.py
    run_agent.py
```

## Quick start

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set your Mistral API key as an environment variable:

```bash
export MISTRAL_API_KEY="your_api_key_here"
```

3. Implement `build_memory_store()` in `src/memory_store.py`, then run:

```bash
python -m src.memory_store
```

4. Run the agent:

```bash
python -m src.run_agent
```

## Notes

- `sample_sources.json` contains example source objects.
- `sample_index.json` contains an example memory index format.
- Minimal expected fields are `text` plus optional metadata such as `url`, `title`, or `source`.
- This scaffold is intentionally simple so you can replace each module with stronger logic later (e.g., embeddings, LLM prompting, richer state).
