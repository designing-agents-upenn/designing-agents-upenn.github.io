"""Agent runner: wire memory, content, style, and chat loop."""

from .content_module import content_step
from .memory_store import load_memory_store
from .style_module import stylize


def should_end(user_message: str) -> bool:
    """Determine if the conversation should end."""
    raise NotImplementedError

def add_signoff(response: str) -> str:
    """Add a signoff to the response."""
    raise NotImplementedError

def run() -> None:
    """Run a basic CLI chat loop."""
    memory_store = load_memory_store()
    print(f"Loaded memory store from data/store.json.")

    while True:
        user_message = input("You: ").strip()
        if not user_message:
            continue

        result = content_step(memory=memory_store, user_message=user_message)
        content_plan = result["content_plan"]
        response = stylize(content_plan=content_plan)

        if should_end(user_message):
            response = add_signoff(response)
            print(f"Agent: {response}")
            break

        print(f"Agent: {response}")


if __name__ == "__main__":
    run()
