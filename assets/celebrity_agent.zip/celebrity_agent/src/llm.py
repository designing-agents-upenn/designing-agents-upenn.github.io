"""Mistral client helper for HW3."""

import os
from mistralai import Mistral

MODEL_NAME = "mistral-small-latest" # feel free to change this to a different model

def query_llm(prompt: str, temperature: float = 0.0) -> str:
    """Send a prompt to Mistral and return the raw string response."""
    api_key = os.getenv("MISTRAL_API_KEY")
    if not api_key:
        raise RuntimeError(
            "Missing MISTRAL_API_KEY environment variable. "
            "Set it before calling query_llm()."
        )
    try:
        client = Mistral(api_key=api_key)
        response = client.chat.complete(
            model=MODEL_NAME,
            temperature=temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content
    except Exception as e:
        raise RuntimeError(f"Error querying LLM: {e}")
